import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed data on startup
  await storage.seedApps();

  app.get(api.apps.list.path, async (req, res) => {
    const apps = await storage.getApps();
    res.json(apps);
  });

  return httpServer;
}
