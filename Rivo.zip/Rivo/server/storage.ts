import { db } from "./db";
import { apps, type App, type InsertApp } from "@shared/schema";

export interface IStorage {
  getApps(): Promise<App[]>;
  seedApps(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getApps(): Promise<App[]> {
    return await db.select().from(apps);
  }

  async seedApps(): Promise<void> {
    const existing = await db.select().from(apps);
    if (existing.length === 0) {
      await db.insert(apps).values([
        { name: "Rivo AI", icon: "Bot", path: "/ai", description: "AI Assistant", isExternal: false },
        { name: "Rivo Search", icon: "Search", path: "/search", description: "Search Engine", isExternal: false },
        { name: "Rivo Docs", icon: "FileText", path: "/docs", description: "Documents", isExternal: false },
        { name: "Rivo Drive", icon: "HardDrive", path: "/drive", description: "File Storage", isExternal: false },
        { name: "Rivo Sites", icon: "Layout", path: "/sites", description: "Website Builder", isExternal: false },
        { name: "Settings", icon: "Settings", path: "/settings", description: "App Settings", isExternal: false },
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
